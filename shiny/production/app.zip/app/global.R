############################################################################################
#
#  Global file
#
#############################################################################################

# * 1 Load libraries ----------------------- -------------------------------

# list of required packages
required_packages <- c(
  "shiny", "bs4Dash", "dplyr", "rlang", "scales", "fresh", "lubridate",
  "shinySearchbar", "emayili", "shinyjs", "sever", "shinycssloaders", "shinyWidgets",
  "reactablefmtr", "reactable", "htmltools", "htmlwidgets"
)

# Load each package
invisible(lapply(required_packages, function(pkg) {
  library(pkg, character.only = TRUE)
}))

# * 2 Load .Renviron -----------------------------------------------------------

readRenviron("/home/hugo/app/.Renviron")

# * 3 Load functions -----------------------------------------------------------

source("functions/func_accordion.R")
source("functions/func_cell_layout.R")
source("functions/func_colours_fresh.R")
source("functions/func_email.R")
source("functions/func_filters.R")
source("functions/func_column_defs.R")
source("functions/func_row_defs.R")
source("functions/func_mandatory_fields.R")
source("functions/func_reset_fields.R")

# * 4 Load modules -----------------------------------------------------------

source("modules/mod_controlbar.R")
source("modules/mod_header.R")
source("modules/mod_app_info.R")
source("modules/mod_prod_filter.R")
source("modules/mod_feat_filter.R")
source("modules/mod_sub_data.R")
source("modules/mod_article.R")
source("modules/mod_about.R")
source("modules/mod_contact.R")
source("modules/mod_footer.R")
source("modules/mod_timeout.R")

#  * 5 load data -----------------------------------------------
sia_df <- get(load(file.path("data", "df_sia_wearable_app.RData")))

#remove column id
sia_df$id <- NULL

#  * 6 calculate no of wearables for home page -----------------------------------------------
n_wearables <- nrow(sia_df)

#  * 7 set spinner table -----------------------------------------------
options(spinner.type = 5, spinner.color = "#f15a29", spinner.size = 0.5, hide.ui = FALSE)

#  * 8 reactable layout -----------------------------------------------

#  * * 8.1 colours -----------------------------------------------

#  sticky columns color
sticky_style <- list(backgroundColor = "#f7f7f7")

# base color palette numerical columns
pal_num_scale <- generate_alpha_palette("#1c75bc", 100)

#  * * 8.2 cells -----------------------------------------------

#bars columns
bar_vars <- c("sia_es_long", "sia_es_short")

# numerical columns
numeric_vars <- names(sia_df)[sapply(sia_df, is.numeric) & !names(sia_df) %in% bar_vars]

# save min and max per column
numeric_var_ranges <- lapply(numeric_vars, function(var) {
  range(sia_df[[var]], na.rm = TRUE)
})
names(numeric_var_ranges) <- numeric_vars

# yes/no columns
yn_vars <- names(sia_df)[sapply(sia_df, is.character) & names(sia_df) != "release_date" & sapply(sia_df, function(x) any(x %in% c("Yes", "No"), na.rm = TRUE))]

#char columns to rename
char_vars <- setdiff(names(sia_df), c(names(bar_vars), names(yn_vars), names(numeric_vars), "id"))

#  * 9 Mandatory fields ---------------------------

fieldsMandatory_data <- c("name","email","manufacturer","model","website","market_status","main_use",
                          "device_cost","wearable_type","location","weight","size")

# IDs that must NOT contain digits or CSV delimiters
char_no_digit_ids <- c(
  "name","market_status","main_use","wearable_type","location",
  "other_signals","data_trans_method"
)

# you already have char_vars defined elsewhere
csv_only_ids <- union(setdiff(char_vars, char_no_digit_ids), "additional_information")

char_no_digit_mand <- intersect(char_no_digit_ids, fieldsMandatory_data)

csv_delims_pattern <- "[,;]"

# * * 9.2 email
fieldsMandatory_email <- c("name", "email", "message")

# * 10 Rename table variables ---------------------------

# * * 10.1 Filters ---------------------------

rename_map <- c(
  "sia_es_long" = "Long-Term SiA Score",
  "sia_es_short" = "Short-Term SiA Score",
  "manufacturer" = "Manufacturer",
  "model" = "Model",
  "website" = "Website",
  "release_date" = "Release Date",
  "market_status" = "Market Status",
  "main_use" = "Main Use",
  "device_cost" = "Cost (€)",
  "wearable_type" = "Type",
  "location" = "Location",
  "weight" = "Weight (g)",
  "size" = "Size",
  "water_resistance" = "Water Resistant",
  "battery_life" = "Battery Life (min)",
  "charging_method" = "Charging Method",
  "charging_duration" = "Charging Duration (min)",
  "bio_cueing" = "Bio Cueing",
  "bio_feedback" = "Bio Feedback",
  "ppg" = "PPG",
  "ecg" = "ECG",
  "icg" = "ICG",
  "emg" = "EMG",
  "respiration" = "Respiration",
  "eda" = "EDA",
  "eeg" = "EEG",
  "bp" = "Blood Pressure",
  "accelerometer" = "Accelerometer",
  "gyroscope" = "Gyroscope",
  "gps" = "GPS",
  "skin_temperature" = "Skin Temperature",
  "other_signals" = "Other Signals",
  "raw_data_available" = "Raw Data Available",
  "data_trans_method" = "Data Transmission Method",
  "int_storage_met" = "Internal Storage",
  "server_data_storage" = "Server Data Storage",
  "dev_storage_cap_hrs" = "Device Storage (hrs)",
  "dev_storage_cap_mb" = "Device Storage (MB)",
  "gdpr_comp" = "GDPR Compliant",
  "fda_app_clear" = "FDA Approved",
  "ce_app_label" = "CE Label",
  "level_validation" = "Validation Level",
  "no_studies_val_rel_reviewed" = "Validation Studies Reviewed",
  "no_studies_usab_reviewed" = "Usability Studies Reviewed"
)

# * * 10.1 Submit data ---------------------------

rename_subm<- names(rename_map)

rename_subm <- rename_subm[!rename_subm %in% c("sia_es_long", "sia_es_short")]

rename_subm <- c("name", "email", "telephone", "institution", rename_subm, "additional_information")

#  * 11 Time-out message -----------------------------------------------
disconnected <- tagList(
  p(strong("Time Out!", style = "color: #1c75bc; font-size:30px")),
  p(tags$img(src = "favicon.ico", height = 100, width = 100)),
  p("You haven't been active for over 1 hour", br(),
    "or your system went into sleep mode.", br(),
    "To help", strong("Un-Stress", style = "color: #f15a29; font-size:18px"), "the server", br(),
    "your session has ended.", style = "font-size:16px"),
  p(reload_button("Refresh")),
  p("Just hit refresh to continue", br(),
    "where you left off!", style = "font-size:16px")
)



